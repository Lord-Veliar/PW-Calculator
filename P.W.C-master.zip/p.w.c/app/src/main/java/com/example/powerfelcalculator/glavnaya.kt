package com.example.powerfelcalculator

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.widget.SwitchCompat
import com.google.firebase.Firebase
import com.google.firebase.firestore.SetOptions
import com.google.firebase.firestore.firestore
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException

class glavnaya : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_glavnaya)
        val db = Firebase.firestore
        var starp = findViewById<EditText>(R.id.starpar)
        var newpar = findViewById<EditText>(R.id.newpar)
        var newparecho = findViewById<EditText>(R.id.newparecho)
        var file_name = "configur.txt"
        var fin: FileInputStream? = null
        var vlog = findViewById<TextView>(R.id.vlog)
        fin = openFileInput(file_name)
        var bytes = ByteArray(fin.available())
        fin.read(bytes)
        var textf = String(bytes)
        if (textf != null) {
            vlog.text = textf
        }
        var istor = findViewById<Button>(R.id.istoria)
        istor.setOnClickListener {
            var intent = Intent(this, Istoriaaa::class.java)
            startActivity(intent)
        }
        var pw = findViewById<Button>(R.id.pw)
        pw.setOnClickListener {
            var intent2 = Intent(this, calculator::class.java)
            startActivity(intent2)
        }
        var viiti = findViewById<Button>(R.id.viiti)
        viiti.setOnClickListener {
            var file_name = "configur.txt"
            var fos: FileOutputStream? = null
            try {
                var dannie: String = ""
                fos = openFileOutput(file_name, MODE_PRIVATE)
                fos.write(dannie.toByteArray())

            } catch (ex: IOException) {

            } finally {
                try {
                    fos?.close()
                } catch (ex: IOException) {

                }
            }
            this.finishAffinity()
        }
        var smena = findViewById<Button>(R.id.smena)
        smena.setOnClickListener {
            Toast.makeText(this, "Функция временно недоступна", Toast.LENGTH_LONG).show()
           /* db.collection("users")
                .get()
                .addOnSuccessListener { result ->
                    for (document in result) {
                        if (document.getString("login") == vlog.text.toString())
                        {
if(document.getString("parol")== starp.text.toString())
{
    if(newpar.text.toString()!=""&&newparecho.text.toString()!="")
    {
        if (newpar.text.toString() == newparecho.text.toString())
        {
            val columnReference = db.document("parol")
            val data = hashMapOf(
                "parol" to newpar.text.toString()
            )

            columnReference.update(data as Map<String, Any>)
        }
        else
        {
            Toast.makeText(this, "Пароли не совпадают", Toast.LENGTH_LONG)
        }
    }
    else
    {
        Toast.makeText(this, "Заполните все необходимые поля", Toast.LENGTH_LONG)
    }
}
                            else
                            {
    Toast.makeText(this, "Текущий пароль указан неверно", Toast.LENGTH_LONG)
                            }
                        }
                    }
                }*/

        }
    }
}