package com.example.powerfelcalculator

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.Firebase
import com.google.firebase.firestore.firestore
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var email = findViewById<EditText>(R.id.login)
        var pw = findViewById<EditText>(R.id.parol)
        val db = Firebase.firestore
        var registr = findViewById<Button>(R.id.registr)
        var vhod = findViewById<Button>(R.id.vhod)
        var prov =0
        var file_name="configur.txt"
var prot=0
        val filee: File = File(filesDir,file_name)
        if(!filee.exists()) {
            prot=1

        } else {

        }
        if(prot==0) {
            var fin: FileInputStream? = null

            fin = openFileInput(file_name)
            var bytes = ByteArray(fin.available())
            fin.read(bytes)
            var textf = String(bytes)
            if (textf != null && textf != "") {
                var intent4 = Intent(this, glavnaya::class.java)
                startActivity(intent4)
            }
        }
        registr.setOnClickListener{
            var intent1 = Intent(this, registratia::class.java)
            startActivity(intent1)
        }


        vhod.setOnClickListener {
            progress(true)
            if(email.text.toString()!=null&&pw.text.toString()!=null) {
                db.collection("users")
                    .get()
                    .addOnSuccessListener { result ->
                        for (document in result) {
                            if (document.getString("login") == email.text.toString()) {
                                if (document.getString("parol") == pw.text.toString()) {

                                    saveText()
                                    openText()
                                    prov = 1
                                    var intent3 = Intent(this, glavnaya::class.java)
                                    startActivity(intent3)
                                    progress(inPr = false)

                                }

                            }

                        }
                        if (prov == 0) {
                            Toast.makeText(this, "Неверные данные для входа", Toast.LENGTH_LONG)
                                .show()
                            progress(inPr = false)
                        }
                    }
                    .addOnFailureListener { exception ->
                        Toast.makeText(
                            this,
                            "Произошла ошибка подключения к серверу",
                            Toast.LENGTH_LONG
                        ).show()
                        progress(inPr = false)
                    }
            }
            else
            {
                Toast.makeText(this, "Заполните все необходимые поля", Toast.LENGTH_LONG)
                progress(inPr = false)
            }

        }

    }
   fun saveText() {
       var email = findViewById<EditText>(R.id.login)
       var pw = findViewById<EditText>(R.id.parol)
       val db = Firebase.firestore
       var registr = findViewById<Button>(R.id.registr)
       var vhod = findViewById<Button>(R.id.vhod)
       var prov =0
       var file_name="configur.txt"
        var fos: FileOutputStream? = null
        try {
            var dannie = email.text.toString()
            fos = openFileOutput(file_name, MODE_PRIVATE)
            fos.write(dannie.toByteArray())

        } catch (ex: IOException) {

        } finally {
            try {
                fos?.close()
            } catch (ex: IOException) {

            }
        }
    }
    fun openText()
    {
        var file_name="configur.txt"
        var fin: FileInputStream? = null

            fin = openFileInput(file_name)
            var bytes = ByteArray(fin.available())
            fin.read(bytes)
            var textf = String(bytes)
            Toast.makeText(this, "С возвращением, "+textf, Toast.LENGTH_SHORT).show()



    }
    fun progress(inPr: Boolean){
        if(inPr){
            var pr = findViewById<ProgressBar>(R.id.progressBar)
            pr.visibility = View.VISIBLE
            var but = findViewById<Button>(R.id.vhod)
            but.visibility = View.GONE
            var reg = findViewById<Button>(R.id.registr)
            reg.visibility = View.GONE
        }else {
            var pr = findViewById<ProgressBar>(R.id.progressBar)
            pr.visibility = View.GONE
            var but = findViewById<Button>(R.id.vhod)
            but.visibility = View.VISIBLE
            var reg = findViewById<Button>(R.id.registr)
            reg.visibility = View.VISIBLE
        }
    }

}
