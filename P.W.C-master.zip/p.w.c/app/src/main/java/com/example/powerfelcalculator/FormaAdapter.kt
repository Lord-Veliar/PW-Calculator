package com.example.powerfelcalculator

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.powerfelcalculator.databinding.FormaaaBinding
import com.google.firebase.firestore.firestore

class FormaAdapter(): RecyclerView.Adapter<FormaAdapter.NewHolder>() {
    private val List = ArrayList<formaItem>()

    class NewHolder(item: View) : RecyclerView.ViewHolder(item) {
        private val binding = FormaaaBinding.bind(item)


        fun bind(news: formaItem) = with(binding) {
            primer.text = news.primer
            komment.text = news.kommentarii
            datt.text = news.data
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(com.example.powerfelcalculator.R.layout.formaaa, parent, false)
        return NewHolder(view)
    }

    override fun getItemCount(): Int {
        return List.size
    }
    override fun onBindViewHolder(holder: NewHolder, position: Int) {
        holder.bind(List[position])
    }
    fun addNews(news: formaItem) {
        List.add(news)
        notifyDataSetChanged()
    }

}