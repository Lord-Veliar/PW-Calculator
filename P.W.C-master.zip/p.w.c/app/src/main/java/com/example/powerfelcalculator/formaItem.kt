package com.example.powerfelcalculator

data class formaItem(
    var data: String,
    var kommentarii: String,
    var login: String,
    var primer: String,
    var type:String
)
