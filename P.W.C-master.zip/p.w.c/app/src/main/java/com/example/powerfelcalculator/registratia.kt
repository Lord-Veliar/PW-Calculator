package com.example.powerfelcalculator

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.Toast
import com.google.firebase.Firebase
import com.google.firebase.firestore.firestore
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException

class registratia : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registratia)
        var vh = findViewById<Button>(R.id.voiti)
        var rg = findViewById<Button>(R.id.reg)
        var email = findViewById<EditText>(R.id.login)
        var parol = findViewById<EditText>(R.id.parol)
        var paroldva = findViewById<EditText>(R.id.paroldva)
        var protect = 1
        vh.setOnClickListener {
            var intent1 = Intent(this, MainActivity::class.java)
            startActivity(intent1)
        }
        var db = Firebase.firestore

        rg.setOnClickListener {
            progress(true)
            if(parol.text!=null)
            {
if(email.text.toString().length>=5)
{
    if(parol.text.toString().length>=6)
    {
        if(parol.text.toString()==paroldva.text.toString()) {
            db.collection("users")
                .get()
                .addOnSuccessListener { result ->
                    for (document in result) {
                        if (document.getString("login") == email.text.toString())
                        {



                            protect = 0
                        }


                    }
                    if(protect==0)
                    {
                        Toast.makeText(
                            this,
                            "Такой пользователь уже существует",
                            Toast.LENGTH_LONG
                        ).show()
                        progress(inPr = false)
                    }
                    if (protect == 1)
                    {
                        val user = hashMapOf(
                            "login" to email.text.toString(),
                            "parol" to parol.text.toString()

                        )
                        db.collection("users")
                            .add(user)
                            .addOnSuccessListener { documentReference ->
                                saveText()
                                var intent2 = Intent(this, glavnaya::class.java)
                                startActivity(intent2)
                                progress(inPr = false)
                            }
                            .addOnFailureListener { e ->
                                Toast.makeText(
                                    this,
                                    "Произошла ошибка подключения к серверу",
                                    Toast.LENGTH_LONG
                                ).show()
                                progress(inPr = false)
                            }
                    }
                }
        }
        else
        {
            Toast.makeText(this, "Пароли не совпадают", Toast.LENGTH_LONG).show()
            progress(inPr = false)
        }
    }
    else
    {
        Toast.makeText(this, "Пароль должен быть от 6 символов", Toast.LENGTH_LONG).show()
        progress(inPr = false)
    }
}
                else
                {
                    Toast.makeText(this, "Логин должен быть от 5 символов", Toast.LENGTH_LONG).show()
                    progress(inPr = false)
                }

            }
            else
            {
                Toast.makeText(this, "Данные введены некорректно", Toast.LENGTH_LONG).show()
                progress(inPr = false)
            }

// Add a new document with a generated ID

        }
    }
    fun saveText() {
        var email = findViewById<EditText>(R.id.login)
        var pw = findViewById<EditText>(R.id.parol)
        val db = Firebase.firestore
        var registr = findViewById<Button>(R.id.registr)
        var vhod = findViewById<Button>(R.id.vhod)
        var prov =0
        var file_name="configur.txt"
        var fos: FileOutputStream? = null
        try {
            var dannie = email.text.toString()
            fos = openFileOutput(file_name, MODE_PRIVATE)
            fos.write(dannie.toByteArray())

        } catch (ex: IOException) {

        } finally {
            try {
                fos?.close()
            } catch (ex: IOException) {

            }
        }
    }
    fun openText()
    {
        var file_name="configur.txt"
        var fin: FileInputStream? = null

        fin = openFileInput(file_name)
        var bytes = ByteArray(fin.available())
        fin.read(bytes)
        var textf = String(bytes)
        Toast.makeText(this, "Приятно познакомиться, "+ textf, Toast.LENGTH_SHORT).show()



    }
    fun progress(inPr: Boolean){
        if(inPr){
            var pr = findViewById<ProgressBar>(R.id.progressBar2)
            pr.visibility = View.VISIBLE
            var but = findViewById<Button>(R.id.voiti)
            but.visibility = View.GONE
            var reg = findViewById<Button>(R.id.reg)
            reg.visibility = View.GONE
        }else {
            var pr = findViewById<ProgressBar>(R.id.progressBar2)
            pr.visibility = View.GONE
            var but = findViewById<Button>(R.id.voiti)
            but.visibility = View.VISIBLE
            var reg = findViewById<Button>(R.id.reg)
            reg.visibility = View.VISIBLE
        }
    }

}