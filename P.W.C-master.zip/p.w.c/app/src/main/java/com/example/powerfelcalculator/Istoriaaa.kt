package com.example.powerfelcalculator

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.powerfelcalculator.databinding.ActivityIstoriaaaBinding
import com.google.firebase.Firebase
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.firestore
import java.io.FileInputStream
import java.io.IOException



class Istoriaaa : AppCompatActivity() {
    lateinit var binding: ActivityIstoriaaaBinding
    private val FormaAdapterr = FormaAdapter()
    val db = Firebase.firestore
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_istoriaaa)
        binding = ActivityIstoriaaaBinding.inflate(layoutInflater)
        setContentView(binding.root)



        getDannie()

    }




    fun getDannie(){





        var file_name="configur.txt"
        var fin: FileInputStream? = null

            fin = openFileInput(file_name)
            var bytes = ByteArray(fin.available())
            fin.read(bytes)
           var lgnn=String(bytes)




        db.collection("vichislenia")
            .get()

            .addOnSuccessListener { result ->
                for (document in result) {
                    if(document.getString("login").toString()==lgnn.toString()) {
                        var data = ArrayList<formaItem>()
                        data.add(
                            formaItem(
                                document.getString("data")!!,
                                document.getString("kommentarii")!!,
                                document.getString("login")!!,
                                document.getString("primer")!!,
                                document.getString("type")!!
                            )
                        )

                        runOnUiThread { InitForma(data!!) }
                    }
                }
            }
            .addOnFailureListener { exception ->

            }
    }
    fun InitForma(data: ArrayList<formaItem>){
        with(binding){
            formaView.layoutManager = LinearLayoutManager(this@Istoriaaa,LinearLayoutManager.VERTICAL,false)
            formaView.adapter = FormaAdapterr
            val ListADD: ArrayList<formaItem> = data!!
            if(ListADD.isNotEmpty())
            {
                for(element in ListADD){
                    FormaAdapterr.addNews(element)
                }
            }
        }
    }
}