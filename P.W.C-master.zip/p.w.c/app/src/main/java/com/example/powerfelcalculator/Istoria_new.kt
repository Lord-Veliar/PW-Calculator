package com.example.powerfelcalculator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.google.firebase.Firebase
import com.google.firebase.firestore.firestore
import java.io.FileInputStream
import java.io.IOException

class Istoria_new : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_istoria_new)
        val db = Firebase.firestore
        var lgn="user"
        var datas = findViewById<TextView>(R.id.datee)
        var primers = findViewById<TextView>(R.id.primeer)
        var komm = findViewById<TextView>(R.id.kommiit)
        var file_name="configur.txt"
        var fin: FileInputStream? = null
        try {
            fin = openFileInput(file_name)
            var bytes = ByteArray(fin.available())
            fin.read(bytes)
            var text = String(bytes)
            lgn=String(bytes)
            Toast.makeText(this, "Вход выполнен", Toast.LENGTH_SHORT).show()
        } catch (ex: IOException) {
            Toast.makeText(this, ex.message, Toast.LENGTH_SHORT).show()
        } finally {
            try {
                fin?.close()
            } catch (ex: IOException) {
                Toast.makeText(this, ex.message, Toast.LENGTH_SHORT).show()
            }
        }
        db.collection("vichislenia")
            .get()
            .addOnSuccessListener { result ->
                for (document in result) {
                    if (document.getString("login") == lgn) {
datas.text=document.getString("data")
                        primers.text=document.getString("primer")
                        komm.text=document.getString("kommentarii")
                    }
                }
            }
            .addOnFailureListener { exception ->

            }
    }
}