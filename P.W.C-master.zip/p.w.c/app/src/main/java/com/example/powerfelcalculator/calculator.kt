package com.example.powerfelcalculator

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.google.firebase.Firebase
import com.google.firebase.firestore.firestore
import java.io.FileInputStream
import java.io.IOException
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.ZonedDateTime

class calculator : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_calculator)
        var minus = findViewById<TextView>(R.id.minus)
        var tablo = findViewById<TextView>(R.id.tablo)
        var plus = findViewById<TextView>(R.id.plus)
        var delit = findViewById<TextView>(R.id.delit)
        var umnoz = findViewById<TextView>(R.id.umnoz)
        var steret = findViewById<TextView>(R.id.steret)
        var f0 = findViewById<TextView>(R.id.f0)
        var f1 = findViewById<TextView>(R.id.f1)
        var f2 = findViewById<TextView>(R.id.f2)
        var f3 = findViewById<TextView>(R.id.f3)
        var f4 = findViewById<TextView>(R.id.f4)
        var f5 = findViewById<TextView>(R.id.f5)
        var f6 = findViewById<TextView>(R.id.f6)
        var f7 = findViewById<TextView>(R.id.f7)
        var f8 = findViewById<TextView>(R.id.f8)
        var f9 = findViewById<TextView>(R.id.f9)
        var ravno = findViewById<TextView>(R.id.ravn)
        var komm = findViewById<EditText>(R.id.komm)
        var nazad = findViewById<TextView>(R.id.nazad)
        var sohr = findViewById<TextView>(R.id.sohr)
        var pipka = findViewById<TextView>(R.id.pipka)

        pipka.isEnabled=false
        sohr.isEnabled=false
        vikl()
        var vic=""
        pipka.setOnClickListener{
            tablo.text = tablo.text.toString()+"."
            pipka.isEnabled=false
            sohr.isEnabled=false
        }
        nazad.setOnClickListener{
            var intent66 = Intent(this, glavnaya::class.java)
            startActivity(intent66)
        }
        f0.setOnClickListener{
            tablo.text=tablo.text.toString()+"0"
            vkl()
            sohr.isEnabled=false

        }
        f1.setOnClickListener{
            tablo.text=tablo.text.toString()+"1"
            vkl()
            sohr.isEnabled=false

        }
        f2.setOnClickListener{
            tablo.text=tablo.text.toString()+"2"
            vkl()
            sohr.isEnabled=false

        }
        f3.setOnClickListener{
            tablo.text=tablo.text.toString()+"3"
            vkl()
            sohr.isEnabled=false

        }
        f4.setOnClickListener{
            tablo.text=tablo.text.toString()+"4"
            vkl()
            sohr.isEnabled=false

        }
        f5.setOnClickListener{
            tablo.text=tablo.text.toString()+"5"
            vkl()
            sohr.isEnabled=false

        }
        f6.setOnClickListener{
            tablo.text=tablo.text.toString()+"6"
            vkl()
            sohr.isEnabled=false

        }
        f7.setOnClickListener{
            tablo.text=tablo.text.toString()+"7"
            vkl()
            sohr.isEnabled=false

        }
        f8.setOnClickListener{
            tablo.text=tablo.text.toString()+"8"
            vkl()
            sohr.isEnabled=false

        }
        f9.setOnClickListener{
            tablo.text=tablo.text.toString()+"9"
            vkl()
            sohr.isEnabled=false

        }
        steret.setOnClickListener{
            tablo.text=""
            vikl()
            vic=""
            sohr.isEnabled=false
        }
        minus.setOnClickListener{
            var l = 0;
           tablo.text.toString().forEach {
               if (it == '-' || it == '+' || it == '×' || it == '÷')
               {
                   l++
               }
           }


            if (l > 0)
            {
                var ch1 = 0.0;
                var ch2 = 0.0;
                var znak= ""
                var buffer = tablo.text.toString().split(' ') as ArrayList<String>

                ch1 = buffer[0].toDouble();
                znak = buffer[1];
                ch2 = buffer[2].toDouble();
                if (znak == "-")
                {
                    sohr.isEnabled=true
                    vic+="("+ch1+znak+ch2+")"
                    tablo.text = (ch1-ch2).toString()
                    vic+="="+tablo.text.toString()
                    tablo.text=tablo.text.toString()+" - "


                }
                if (znak == "+")
                { sohr.isEnabled=true

                    sohr.isEnabled=true
                    vic+="("+ch1+znak+ch2+")"
                    tablo.text = (ch1+ch2).toString()
                    vic+="="+tablo.text.toString()
                    tablo.text=tablo.text.toString()+" - "
                }
                if (znak == "×")
                {

                    sohr.isEnabled=true
                    vic+="("+ch1+znak+ch2+")"
                    tablo.text = (ch1*ch2).toString()
                    vic+="="+tablo.text.toString()
                    tablo.text=tablo.text.toString()+" - "
                }
                if (znak == "÷")
                {
                    sohr.isEnabled=true
                    vic+="("+ch1+znak+ch2+")"
                    tablo.text = (ch1/ch2).toString()
                    vic+="="+tablo.text.toString()
                    tablo.text=tablo.text.toString()+" - "
                }


            }
            else
            {
               tablo.text=tablo.text.toString()+" - "

            }
            vikl();
        }
        plus.setOnClickListener{
            var l = 0;
            tablo.text.toString().forEach {
                if (it == '-' || it == '+' || it == '×' || it == '÷')
                {
                    l++
                }
            }


            if (l > 0)
            {
                var ch1 = 0.0;
                var ch2 = 0.0;
                var znak= ""
                var buffer = tablo.text.toString().split(' ') as ArrayList<String>

                ch1 = buffer[0].toDouble();
                znak = buffer[1];
                ch2 = buffer[2].toDouble();
                if (znak == "-")
                {  vic+="("+ch1+znak+ch2+")"

                    sohr.isEnabled=true
                    vic+="("+ch1+znak+ch2+")"
                    tablo.text = (ch1-ch2).toString()
                    vic+="="+tablo.text.toString()
                    tablo.text=tablo.text.toString()+" + "
                }
                if (znak == "+")
                {

                    sohr.isEnabled=true
                    vic+="("+ch1+znak+ch2+")"
                    tablo.text = (ch1+ch2).toString()
                    vic+="="+tablo.text.toString()
                    tablo.text=tablo.text.toString()+" + "
                }
                if (znak == "×")
                {

                    sohr.isEnabled=true
                    vic+="("+ch1+znak+ch2+")"
                    tablo.text = (ch1*ch2).toString()
                    vic+="="+tablo.text.toString()
                    tablo.text=tablo.text.toString()+" + "
                }
                if (znak == "÷")
                {

                    sohr.isEnabled=true
                    vic+="("+ch1+znak+ch2+")"
                    tablo.text = (ch1/ch2).toString()
                    vic+="="+tablo.text.toString()
                    tablo.text=tablo.text.toString()+" + "
                }


            }
            else
            {
                tablo.text=tablo.text.toString()+" + "
            }
            vikl();
        }
        umnoz.setOnClickListener{
            var l = 0;
            tablo.text.toString().forEach {
                if (it == '-' || it == '+' || it == '×' || it == '÷')
                {
                    l++
                }
            }


            if (l > 0)
            {
                var ch1 = 0.0;
                var ch2 = 0.0;
                var znak= ""
                var buffer = tablo.text.toString().split(' ') as ArrayList<String>

                ch1 = buffer[0].toDouble();
                znak = buffer[1];
                ch2 = buffer[2].toDouble();
                if (znak == "-")
                {

                    sohr.isEnabled=true
                    vic+="("+ch1+znak+ch2+")"
                    tablo.text = (ch1-ch2).toString()
                    vic+="="+tablo.text.toString()
                    tablo.text=tablo.text.toString()+" × "
                }
                if (znak == "+")
                {

                    sohr.isEnabled=true
                    vic+="("+ch1+znak+ch2+")"
                    tablo.text = (ch1+ch2).toString()
                    vic+="="+tablo.text.toString()
                    tablo.text=tablo.text.toString()+" × "
                }
                if (znak == "×")
                { sohr.isEnabled=true

                    sohr.isEnabled=true
                    vic+="("+ch1+znak+ch2+")"
                    tablo.text = (ch1*ch2).toString()
                    vic+="="+tablo.text.toString()
                    tablo.text=tablo.text.toString()+" × "
                }
                if (znak == "÷")
                {

                    sohr.isEnabled=true
                    vic+="("+ch1+znak+ch2+")"
                    tablo.text = (ch1/ch2).toString()
                    vic+="="+tablo.text.toString()
                    tablo.text=tablo.text.toString()+" × "
                }


            }
            else
            {
                tablo.text=tablo.text.toString()+" × "

            }
            vikl();
        }
        delit.setOnClickListener{
            var l = 0;
            tablo.text.toString().forEach {
                if (it == '-' || it == '+' || it == '×' || it == '÷')
                {
                    l++
                }
            }


            if (l > 0)
            {
                var ch1 = 0.0;
                var ch2 = 0.0;
                var znak= ""
                var buffer = tablo.text.toString().split(' ') as ArrayList<String>

                ch1 = buffer[0].toDouble();
                znak = buffer[1];
                ch2 = buffer[2].toDouble();
                if (znak == "-")
                {

                    sohr.isEnabled=true
                    vic+="("+ch1+znak+ch2+")"
                    tablo.text = (ch1/ch2).toString()
                    vic+="="+tablo.text.toString()
                    tablo.text=tablo.text.toString()+" ÷ "

                }
                if (znak == "+")
                {

                    sohr.isEnabled=true
                    vic+="("+ch1+znak+ch2+")"
                    tablo.text = (ch1/ch2).toString()
                    vic+="="+tablo.text.toString()
                    tablo.text=tablo.text.toString()+" ÷ "

                }
                if (znak == "×")
                {

                    sohr.isEnabled=true
                    vic+="("+ch1+znak+ch2+")"
                    tablo.text = (ch1/ch2).toString()
                    vic+="="+tablo.text.toString()
                    tablo.text=tablo.text.toString()+" ÷ "

                }
                if (znak == "÷")
                {

                    sohr.isEnabled=true
                    vic+="("+ch1+znak+ch2+")"
                    tablo.text = (ch1/ch2).toString()
                    vic+="="+tablo.text.toString()
                    tablo.text=tablo.text.toString()+" ÷ "
                }


            }
            else
            {
                tablo.text=tablo.text.toString()+" ÷ "

            }
            vikl();
        }
        ravno.setOnClickListener{
            sohr.isEnabled=true
            var l = 0;
            tablo.text.toString().forEach {
                if (it == '-' || it == '+' || it == '×' || it == '÷')
                {
                    l++
                }
            }


            if (l > 0)
            {
                var ch1 = 0.0;
                var ch2 = 0.0;
                var znak= ""
                var buffer = tablo.text.toString().split(' ') as ArrayList<String>

                ch1 = buffer[0].toDouble();
                znak = buffer[1];
                ch2 = buffer[2].toDouble();
                if (znak == "-")
                {vic+="("+ch1+znak+ch2+")"
                    tablo.text = (ch1-ch2).toString();
                }
                if (znak == "+")
                {
                    vic+="("+ch1+znak+ch2+")"
                    tablo.text = (ch1+ch2).toString();
                }
                if (znak == "×")
                {
                    vic+="("+ch1+znak+ch2+")"
                    tablo.text = (ch1 * ch2).toString();
                }
                if (znak == "÷")
                {
                    vic+="("+ch1+znak+ch2+")"
                    tablo.text = (ch1 / ch2).toString();
                }


            }
            else
            {
                tablo.text=tablo.text.toString()
                vic+="="+tablo.text.toString()
            }
            vikl();
        }
        sohr.setOnClickListener{
            vic=vic+"="+tablo.text.toString()
            var db = Firebase.firestore
var lgnn="user"
                var file_name="configur.txt"
                var fin: FileInputStream? = null
                try {
                    fin = openFileInput(file_name)
                    var bytes = ByteArray(fin.available())
                    fin.read(bytes)
                    lgnn = String(bytes)

                } catch (ex: IOException) {

                } finally {
                    try {
                        fin?.close()
                    } catch (ex: IOException) {
                    }
                }

           var dt = LocalDateTime.now().format(DateTimeFormatter.ofPattern("MMM dd yyyy, hh:mm:ss a"))
            val dannie = hashMapOf(
              "data" to dt,
                "kommentarii" to komm.text.toString(),
                "login" to lgnn,
                "primer" to vic,
                "type" to "Стандартные вычисления"
            )


            db.collection("vichislenia")
                .add(dannie)
                .addOnSuccessListener { documentReference ->
                    Toast.makeText(this, "Данные сохранены", Toast.LENGTH_SHORT).show()
                }
                .addOnFailureListener { e ->
                    Toast.makeText(this, "Ошибка отправки данных на сервер", Toast.LENGTH_SHORT).show()
                }

        }


    }
    fun vikl()
    {
        var minus = findViewById<TextView>(R.id.minus)
        minus.isEnabled=false
        var plus = findViewById<TextView>(R.id.plus)
        plus.isEnabled=false
        var delit = findViewById<TextView>(R.id.delit)
        delit.isEnabled=false
        var umnoz = findViewById<TextView>(R.id.umnoz)
        umnoz.isEnabled=false
        var ravno = findViewById<TextView>(R.id.ravn)
        ravno.isEnabled=false
        var pipka = findViewById<TextView>(R.id.pipka)
        pipka.isEnabled=false



    }
    fun vkl()
    {
        var minus = findViewById<TextView>(R.id.minus)
        minus.isEnabled=true
        var plus = findViewById<TextView>(R.id.plus)
        plus.isEnabled=true
        var delit = findViewById<TextView>(R.id.delit)
        delit.isEnabled=true
        var umnoz = findViewById<TextView>(R.id.umnoz)
        umnoz.isEnabled=true
        var ravno = findViewById<TextView>(R.id.ravn)
        ravno.isEnabled=true
        var pipka = findViewById<TextView>(R.id.pipka)
        pipka.isEnabled=true

    }
}